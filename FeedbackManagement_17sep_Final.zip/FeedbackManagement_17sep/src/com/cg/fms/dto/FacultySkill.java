package com.cg.fms.dto;

public class FacultySkill {
	
	private int facultyId;
	private String skillSet;
	public int getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}
	public String getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	public FacultySkill(int facultyId, String skillSet) {
		super();
		this.facultyId = facultyId;
		this.skillSet = skillSet;
	}
	public FacultySkill() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "FacultySkill [facultyId=" + facultyId + ", skillSet="
				+ skillSet + "]";
	}
	

}
