package com.cg.fms.dto;

public class Course {
	private int courseId;
	private String courseName;
	private int noOfDays;
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName
				+ ", noOfDays=" + noOfDays + "]";
	}
	public Course(int courseId, String courseName, int noOfDays) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.noOfDays = noOfDays;
	}
	
	public Course(String courseName, int noOfDays) {
		super();
		this.courseName = courseName;
		this.noOfDays = noOfDays;
	}

}
